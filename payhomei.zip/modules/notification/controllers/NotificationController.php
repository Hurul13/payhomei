<?php

namespace app\modules\notification\controllers;

/**
 * This is the class for controller "NotificationController".
 * Modified by Defri Indra
 */
class NotificationController extends \app\modules\notification\controllers\base\NotificationController
{

}
