<?php

namespace app\modules\websetting\controllers;

/**
 * This is the class for controller "WebConfigGroupController".
 * Modified by Defri Indra
 */
class WebConfigGroupController extends \app\modules\websetting\controllers\base\WebConfigGroupController
{

}
