<?php

namespace app\modules\websetting\controllers;

/**
 * This is the class for controller "WebConfigController".
 * Modified by Defri Indra
 */
class WebConfigController extends \app\modules\websetting\controllers\base\WebConfigController
{

}
