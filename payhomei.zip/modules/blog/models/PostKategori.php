<?php

namespace app\modules\blog\models;

use Yii;
use \app\modules\blog\models\base\PostKategori as BasePostKategori;

/**
 * This is the model class for table "blog_post_kategori".
 * Modified by Defri Indra M
 */
class PostKategori extends BasePostKategori
{
}
