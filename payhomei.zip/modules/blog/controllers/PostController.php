<?php

namespace app\modules\blog\controllers;

/**
 * This is the class for controller "PostController".
 * Modified by Defri Indra
 */
class PostController extends \app\modules\blog\controllers\base\PostController
{
}
