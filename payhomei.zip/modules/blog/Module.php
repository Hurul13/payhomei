<?php

namespace app\modules\blog;

class Module extends \yii\base\Module
{

    public $controllerNamespace = 'app\modules\blog\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
