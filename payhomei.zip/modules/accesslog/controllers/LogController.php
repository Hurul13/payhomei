<?php

namespace app\modules\accesslog\controllers;

/**
 * This is the class for controller "LogController".
 * Modified by Defri Indra
 */
class LogController extends \app\modules\accesslog\controllers\base\LogController
{
}
