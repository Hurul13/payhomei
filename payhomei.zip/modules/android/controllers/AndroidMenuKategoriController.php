<?php

namespace app\modules\android\controllers;

/**
 * This is the class for controller "AndroidMenuKategoriController".
 * Modified by Defri Indra
 */
class AndroidMenuKategoriController extends \app\modules\android\controllers\base\AndroidMenuKategoriController
{
}
