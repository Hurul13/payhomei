<?php

namespace app\modules\android\controllers;

/**
 * This is the class for controller "AndroidBannerKategoriController".
 * Modified by Defri Indra
 */
class AndroidBannerKategoriController extends \app\modules\android\controllers\base\AndroidBannerKategoriController
{

}
