<?php

namespace app\modules\android\controllers;

/**
 * This is the class for controller "AndroidMenuController".
 * Modified by Defri Indra
 */
class AndroidMenuController extends \app\modules\android\controllers\base\AndroidMenuController
{
}
