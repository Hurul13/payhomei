<?php

namespace app\modules\android\controllers;

/**
 * This is the class for controller "AndroidRouteController".
 * Modified by Defri Indra
 */
class AndroidRouteController extends \app\modules\android\controllers\base\AndroidRouteController
{
}
