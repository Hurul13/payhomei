<?php

namespace app\models;

use \app\models\base\RoleAction as BaseRoleAction;

/**
 * This is the model class for table "role_action".
 */
class RoleAction extends BaseRoleAction
{
}
