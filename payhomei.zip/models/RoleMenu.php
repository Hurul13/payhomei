<?php

namespace app\models;

use \app\models\base\RoleMenu as BaseRoleMenu;

/**
 * This is the model class for table "role_menu".
 */
class RoleMenu extends BaseRoleMenu
{
}
