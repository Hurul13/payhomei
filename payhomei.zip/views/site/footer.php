<div class="row warnadasar">
    <div class="col-md-6 col-sm-12 bigpadding">
        <h3>Kontak</h3>
        <p style="padding-top: 10px;padding-left: 5px">
            Indoarta Citra Media<br>
            Sukolilo Park Regency C-22<br>
            Keputih, Sukolilo, Surabaya<br>
            Telepon: 0811-333-525<br>
            Email : febri@indoarta.co.id<br>
        </p>
    </div>
    <div class="col-md-6 col-sm-12 bigpadding">
        <h3>Related Sites</h3>
        <p>
        <ul>
            <li><a href="http://indoarta.co.id/">Indoarta Citra Media</a></li>
        </ul>
        </p>
    </div>
</div>
<div class="row warnagelap">
    <div class="col-md-5 col-sm-12 bigpadding">
        2016 &copy; Indoarta Citra Media
    </div>
</div>